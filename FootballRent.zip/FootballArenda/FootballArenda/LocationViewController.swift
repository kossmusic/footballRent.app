//
//  ViewController.swift
//  Football
//
//  Created by Константин on 22.04.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet  var pickerView: UIPickerView!
    
    var locationSelected = ""
    let array = ["Голосеевский", "Святошинский", "Соломенский", "Оболонский", "Подольский", "Печерский", "Шевченковский", "Дарницкий", "Днепровский", "Деснянский"]
    
    override func viewDidLoad() {
        locationSelected = array[0]
        pickerView.delegate = self
        pickerView.dataSource = self
    }
   
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return array.count
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
          locationSelected = array[row]
        }
    
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return array[row]
        
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
       let destanationVC: PriceViewControler = segue.destinationViewController as! PriceViewControler
       destanationVC.textOfLocationResult1 = locationSelected
    }
}




