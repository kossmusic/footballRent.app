//
//  PriceViewControlerViewController.swift
//  Football
//
//  Created by Константин on 25.04.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

class PriceViewControler: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    @IBOutlet weak var pricePicker: UIPickerView!

    var priceSelected = ""
    var textOfLocationResult1 = ""
    
    let priceArray = ["все поля","0-200 грн/час", "200-500 грн/час", "500-700 грн/час","700-1000 грн/час"]
    
    override func viewDidLoad() {
        priceSelected = priceArray[0]
        pricePicker.delegate = self
        pricePicker.dataSource = self
    }
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return priceArray.count
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        priceSelected = priceArray[row]
        
    }
    
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return priceArray[row]
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let destanationVC: ResultViewController = segue.destinationViewController as! ResultViewController
        destanationVC.textOfpriceResult = priceSelected
        let destanationVC1: ResultViewController = segue.destinationViewController as! ResultViewController
        destanationVC1.textOfLocationResult = textOfLocationResult1
    }
  
}