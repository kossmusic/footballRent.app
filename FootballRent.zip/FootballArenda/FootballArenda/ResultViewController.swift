//
//  ResultViewController.swift
//  Football
//
//  Created by Константин on 27.04.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    
    @IBOutlet weak var locationResult: UILabel!
    var textOfLocationResult:String = ""
    
    @IBOutlet weak var priceResult: UILabel!
    var textOfpriceResult:String = ""
    
     @IBOutlet weak var tableView: UITableView!
    var fieldList = [NSDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationResult.text = textOfLocationResult
        priceResult.text = textOfpriceResult
        finder()
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
    func finder() {
      
        let url = NSBundle.mainBundle().URLForResource("Football Fields List", withExtension: "plist")!
        
        let fieldList = NSArray(contentsOfURL: url)!
        
        let attributeLocation = "location"
      
        let attributePrice = "price"
        
        let attributeLocationValue = locationResult.text!
      
        let attributePriceValue = priceResult.text!
        
        let predicate = NSPredicate(format:"%K CONTAINS[c] %@", attributeLocation, attributeLocationValue)
        
        let res = fieldList.filteredArrayUsingPredicate(predicate) as NSArray
        
        let pricePredicate = NSPredicate(format:"%K CONTAINS[c] %@", attributePrice, attributePriceValue)
        
        let res1 = res.filteredArrayUsingPredicate(pricePredicate)
        
        self.fieldList = res1 as! [NSDictionary]
       
        if priceResult.text == "все поля" {
            
        self.fieldList = res as! [NSDictionary]
            
        tableView.reloadData()
            
        }

        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fieldList.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        
        let dict = fieldList[indexPath.row]
        cell.textLabel!.text = dict["name"] as? String
        cell.detailTextLabel!.text = dict["street"] as? String
        
        return cell
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let cell = sender as? UITableViewCell {
            if let indexPath = tableView.indexPathForCell(cell) {
                let destanationVC: DetailViewController = segue.destinationViewController as! DetailViewController
                destanationVC.selectedFields = fieldList[indexPath.row]
            }
        }
        
    }
  }
