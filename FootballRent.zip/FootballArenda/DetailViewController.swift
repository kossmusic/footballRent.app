//
//  DetailViewController.swift
//  FootballArenda
//
//  Created by Константин on 11.05.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    var selectedFields = NSDictionary()
    
    @IBOutlet weak var labelName: UILabel!
   @IBOutlet weak var labelLocation: UILabel!
    var textLabelLocation:String = ""
   @IBOutlet weak var labelStreet: UILabel!
    var textLabelStreet:String = ""
   @IBOutlet weak var labelPhoneNumber: UILabel!
    var textLabelPhone:String = ""
   @IBOutlet weak var fieldImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelName.text = selectedFields["name"] as? String
        labelStreet.text = selectedFields["street"] as? String
        labelLocation.text = selectedFields["location"] as? String
        labelPhoneNumber.text = selectedFields["phone number"] as? String
        self.fieldImage.image = UIImage(named: (selectedFields["photo"] as? String)!)
   
        //callNumber(textLabelPhone) //////      звонилка на номера  из списка                ///////////////
    }
    
 /*   private func callNumber(phoneNumber:String) {
        if let phoneCallURL:NSURL = NSURL(string: "tel://\(phoneNumber)") {
            let application:UIApplication = UIApplication.sharedApplication()
            if (application.canOpenURL(phoneCallURL)) {
                application.openURL(phoneCallURL);
            }
        }
    }*/
}
